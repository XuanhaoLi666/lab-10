var assert = require('assert');

var linearPoint = require('./linearPoint.js');


describe('linearPoint', function() {

    it('x is 1', function() {
        assert.equal(linearPoint(2, 1, 4), 6);
    });

    it('x is 0', function() {
        assert.equal(linearPoint(2, 0, 4), 4);
    });
    it('x is -1', function() {
        assert.equal(linearPoint(2, -1, 4), 2);
    });

});