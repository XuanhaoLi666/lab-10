module.exports = (m, x, c) => {
    return m * x + c;
}